Sample configuration files for:

SystemD: junkcoind.service
Upstart: junkcoind.conf
OpenRC:  junkcoind.openrc
         junkcoind.openrcconf
CentOS:  junkcoind.init
OS X:    org.junkcoin.junkcoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
